setTimeout(() => {
    document.querySelector('.preloader').style.display ="none"   
}, 4480);



